﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PowerBot.Module
{
    public class VerificationErrors
    {
        public string errorField { get; set; }
        public string errorMessage { get; set; }
    }
}
